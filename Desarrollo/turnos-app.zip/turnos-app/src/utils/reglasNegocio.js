// src/utils/reglasNegocio.js
// Reglas de negocio centralizadas: horas máximas legales, cruces de turno y
// compatibilidad de puesto/capacitación entre empleados.

const db = require('../db');

/** Duración de un turno en horas, soportando turnos nocturnos que cruzan medianoche. */
function duracionHoras(hora_inicio, hora_fin) {
  const [hi, mi] = hora_inicio.split(':').map(Number);
  const [hf, mf] = hora_fin.split(':').map(Number);
  let inicio = hi * 60 + mi;
  let fin = hf * 60 + mf;
  if (fin <= inicio) fin += 24 * 60; // cruza medianoche (turno noche)
  return (fin - inicio) / 60;
}

/** Devuelve el lunes (ISO) de la semana a la que pertenece una fecha YYYY-MM-DD. */
function inicioSemanaISO(fechaStr) {
  const d = new Date(fechaStr + 'T00:00:00');
  const day = d.getDay(); // 0=domingo
  const diff = (day === 0 ? -6 : 1 - day); // lunes como inicio de semana
  d.setDate(d.getDate() + diff);
  return d.toISOString().slice(0, 10);
}

function finSemanaISO(inicioSemana) {
  const d = new Date(inicioSemana + 'T00:00:00');
  d.setDate(d.getDate() + 6);
  return d.toISOString().slice(0, 10);
}

/**
 * Horas ya asignadas a un usuario en la semana ISO que contiene `fecha`,
 * excluyendo opcionalmente una asignación puntual (útil al reemplazar).
 */
function horasAsignadasEnSemana(usuario_id, fecha, excluirAsignacionId = null) {
  const inicio = inicioSemanaISO(fecha);
  const fin = finSemanaISO(inicio);

  const filas = db.prepare(`
    SELECT a.id as asignacion_id, t.hora_inicio, t.hora_fin
    FROM asignaciones a
    JOIN turnos t ON t.id = a.turno_id
    WHERE a.usuario_id = ?
      AND a.estado IN ('asignado','cubierto')
      AND t.fecha BETWEEN ? AND ?
  `).all(usuario_id, inicio, fin);

  return filas
    .filter(f => f.asignacion_id !== excluirAsignacionId)
    .reduce((sum, f) => sum + duracionHoras(f.hora_inicio, f.hora_fin), 0);
}

/**
 * Verifica si asignar `turno` a `usuario_id` respeta el máximo legal de horas
 * semanales del empleado. Devuelve { ok, horasActuales, horasNuevoTotal, maximo }.
 */
function validarMaximoHoras(usuario_id, turno, excluirAsignacionId = null) {
  const usuario = db.prepare('SELECT max_horas_semana FROM usuarios WHERE id = ?').get(usuario_id);
  const maximo = usuario ? usuario.max_horas_semana : 42;
  const horasActuales = horasAsignadasEnSemana(usuario_id, turno.fecha, excluirAsignacionId);
  const horasTurno = duracionHoras(turno.hora_inicio, turno.hora_fin);
  const horasNuevoTotal = horasActuales + horasTurno;
  return {
    ok: horasNuevoTotal <= maximo + 1e-9,
    horasActuales,
    horasTurno,
    horasNuevoTotal,
    maximo,
  };
}

/**
 * Verifica que el nuevo turno no se cruce en fecha/horario con otro turno
 * ya asignado al mismo usuario (evita doble asignación simultánea).
 */
function validarSinCruce(usuario_id, turno, excluirAsignacionId = null) {
  const asignacionesDia = db.prepare(`
    SELECT a.id as asignacion_id, t.fecha, t.hora_inicio, t.hora_fin
    FROM asignaciones a
    JOIN turnos t ON t.id = a.turno_id
    WHERE a.usuario_id = ?
      AND a.estado IN ('asignado','cubierto')
      AND t.fecha = ?
  `).all(usuario_id, turno.fecha);

  const [ni, nf] = [turno.hora_inicio, turno.hora_fin].map(h => {
    const [hh, mm] = h.split(':').map(Number);
    return hh * 60 + mm;
  });
  let nuevoInicio = ni, nuevoFin = nf <= ni ? nf + 24 * 60 : nf;

  for (const a of asignacionesDia) {
    if (a.asignacion_id === excluirAsignacionId) continue;
    const [oi, of_] = [a.hora_inicio, a.hora_fin].map(h => {
      const [hh, mm] = h.split(':').map(Number);
      return hh * 60 + mm;
    });
    let otroInicio = oi, otroFin = of_ <= oi ? of_ + 24 * 60 : of_;

    const seCruzan = nuevoInicio < otroFin && otroInicio < nuevoFin;
    if (seCruzan) {
      return { ok: false, conflicto: a };
    }
  }
  return { ok: true };
}

/** El puesto/capacitación del empleado debe coincidir con el puesto requerido del turno. */
function validarPuestoCompatible(usuario, turno) {
  return usuario.puesto === turno.puesto_requerido;
}

/**
 * Corre TODAS las validaciones necesarias antes de asignar o confirmar un
 * intercambio. Lanza un objeto de error legible si algo falla; si todo está
 * bien, no retorna nada (no-throw).
 */
function validarAsignacionCompleta(usuario, turno, excluirAsignacionId = null) {
  if (!validarPuestoCompatible(usuario, turno)) {
    const err = new Error(
      `El empleado tiene el puesto "${usuario.puesto}" pero el turno requiere "${turno.puesto_requerido}". ` +
      `Solo puede cubrir el turno personal capacitado en el mismo puesto.`
    );
    err.codigo = 'PUESTO_INCOMPATIBLE';
    throw err;
  }

  const cruce = validarSinCruce(usuario.id, turno, excluirAsignacionId);
  if (!cruce.ok) {
    const err = new Error(
      `El empleado ya tiene un turno asignado el ${turno.fecha} que se cruza con este horario (${cruce.conflicto.hora_inicio}-${cruce.conflicto.hora_fin}).`
    );
    err.codigo = 'CRUCE_DE_TURNOS';
    throw err;
  }

  const horas = validarMaximoHoras(usuario.id, turno, excluirAsignacionId);
  if (!horas.ok) {
    const err = new Error(
      `Asignar este turno llevaría al empleado a ${horas.horasNuevoTotal.toFixed(1)}h esta semana, ` +
      `superando el máximo legal de ${horas.maximo}h semanales (Ley 2101 de 2021 / jornada vigente).`
    );
    err.codigo = 'EXCEDE_HORAS_MAXIMAS';
    throw err;
  }

  return horas;
}

module.exports = {
  duracionHoras,
  inicioSemanaISO,
  finSemanaISO,
  horasAsignadasEnSemana,
  validarMaximoHoras,
  validarSinCruce,
  validarPuestoCompatible,
  validarAsignacionCompleta,
};
