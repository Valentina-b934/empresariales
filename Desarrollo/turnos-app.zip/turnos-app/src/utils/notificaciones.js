// src/utils/notificaciones.js
// Notificaciones persistidas en BD + push en tiempo real por WebSocket (socket.io).
// io se inyecta desde server.js con setIo() para evitar dependencias circulares.

const db = require('../db');

let ioInstance = null;
function setIo(io) {
  ioInstance = io;
}

/**
 * Crea una notificación para un usuario y la emite en vivo si está conectado.
 * `tipo`: 'turno_publicado' | 'turno_asignado' | 'intercambio_aceptado' |
 *         'recordatorio' | 'turno_cubierto' | 'info'
 */
function notificar(usuario_id, tipo, mensaje, data = {}) {
  const info = db.prepare(`
    INSERT INTO notificaciones (usuario_id, tipo, mensaje, data_json)
    VALUES (?, ?, ?, ?)
  `).run(usuario_id, tipo, mensaje, JSON.stringify(data));

  const noti = db.prepare('SELECT * FROM notificaciones WHERE id = ?').get(info.lastInsertRowid);

  if (ioInstance) {
    ioInstance.to(`usuario_${usuario_id}`).emit('notificacion', noti);
  }
  return noti;
}

function notificarMuchos(usuarioIds, tipo, mensaje, data = {}) {
  return usuarioIds.map(id => notificar(id, tipo, mensaje, data));
}

module.exports = { setIo, notificar, notificarMuchos };
