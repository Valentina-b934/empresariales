// src/db.js
// Capa de acceso a datos. Usa el módulo SQLite incorporado en Node.js
// (node:sqlite, disponible desde Node 22.5+) en un único archivo local.
// A diferencia de "better-sqlite3", NO requiere compilar nada nativo, así
// que "npm install" nunca falla por falta de Visual Studio Build Tools,
// Python, node-gyp, etc. — funciona igual en Windows, macOS y Linux.

const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');
const { DatabaseSync } = require('node:sqlite');

const DATA_DIR = path.join(__dirname, '..', 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const DB_PATH = path.join(DATA_DIR, 'turnos.db');
const db = new DatabaseSync(DB_PATH);
db.exec('PRAGMA journal_mode = WAL');
db.exec('PRAGMA foreign_keys = ON');

// Emula el helper db.transaction(fn) de better-sqlite3 usando BEGIN/COMMIT/
// ROLLBACK manuales, para no tener que tocar el resto de las rutas que ya
// usan ese patrón (const tx = db.transaction(fn); tx(args)).
db.transaction = function (fn) {
  return function (...args) {
    db.exec('BEGIN');
    try {
      const resultado = fn(...args);
      db.exec('COMMIT');
      return resultado;
    } catch (err) {
      try { db.exec('ROLLBACK'); } catch (_) { /* nada que revertir */ }
      throw err;
    }
  };
};

// ---------------------------------------------------------------------------
// ESQUEMA
// ---------------------------------------------------------------------------
db.exec(`
CREATE TABLE IF NOT EXISTS usuarios (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nombre TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password TEXT NOT NULL,
  rol TEXT NOT NULL CHECK (rol IN ('admin','empleado')),
  puesto TEXT NOT NULL DEFAULT 'general', -- capacitación/cargo: cocinero, mesero, cajero, etc.
  max_horas_semana REAL NOT NULL DEFAULT 42,
  activo INTEGER NOT NULL DEFAULT 1,
  creado_en TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS turnos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  fecha TEXT NOT NULL,               -- YYYY-MM-DD
  tipo_turno TEXT NOT NULL CHECK (tipo_turno IN ('mañana','tarde','noche')),
  hora_inicio TEXT NOT NULL,         -- HH:MM
  hora_fin TEXT NOT NULL,            -- HH:MM
  puesto_requerido TEXT NOT NULL,
  cantidad_requerida INTEGER NOT NULL DEFAULT 1,
  notas TEXT,
  creado_en TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(fecha, tipo_turno, puesto_requerido)
);

CREATE TABLE IF NOT EXISTS asignaciones (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  turno_id INTEGER NOT NULL REFERENCES turnos(id) ON DELETE CASCADE,
  usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
  estado TEXT NOT NULL DEFAULT 'asignado'
    CHECK (estado IN ('asignado','publicado','cubierto','cancelado')),
  origen TEXT NOT NULL DEFAULT 'manual' CHECK (origen IN ('manual','auto','intercambio')),
  creado_en TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(turno_id, usuario_id)
);

CREATE TABLE IF NOT EXISTS disponibilidad (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
  fecha TEXT NOT NULL,
  tipo_turno TEXT NOT NULL CHECK (tipo_turno IN ('mañana','tarde','noche')),
  disponible INTEGER NOT NULL DEFAULT 1,
  UNIQUE(usuario_id, fecha, tipo_turno)
);

CREATE TABLE IF NOT EXISTS intercambios (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  asignacion_id INTEGER NOT NULL REFERENCES asignaciones(id) ON DELETE CASCADE,
  solicitado_por INTEGER NOT NULL REFERENCES usuarios(id),
  aceptado_por INTEGER REFERENCES usuarios(id),
  estado TEXT NOT NULL DEFAULT 'pendiente'
    CHECK (estado IN ('pendiente','aceptado','cancelado','rechazado')),
  motivo TEXT,
  creado_en TEXT NOT NULL DEFAULT (datetime('now')),
  resuelto_en TEXT
);

CREATE TABLE IF NOT EXISTS notificaciones (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
  tipo TEXT NOT NULL,
  mensaje TEXT NOT NULL,
  leida INTEGER NOT NULL DEFAULT 0,
  data_json TEXT,
  creado_en TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_turnos_fecha ON turnos(fecha);
CREATE INDEX IF NOT EXISTS idx_asignaciones_turno ON asignaciones(turno_id);
CREATE INDEX IF NOT EXISTS idx_asignaciones_usuario ON asignaciones(usuario_id);
CREATE INDEX IF NOT EXISTS idx_notif_usuario ON notificaciones(usuario_id, leida);
`);

// ---------------------------------------------------------------------------
// SEED: datos de ejemplo para que el sistema sea usable desde el primer arranque
// ---------------------------------------------------------------------------
function seed() {
  const count = db.prepare('SELECT COUNT(*) AS n FROM usuarios').get().n;
  if (count > 0) return; // ya inicializado

  const hash = (pw) => bcrypt.hashSync(pw, 10);

  const insertUser = db.prepare(`
    INSERT INTO usuarios (nombre, email, password, rol, puesto, max_horas_semana)
    VALUES (@nombre, @email, @password, @rol, @puesto, @max_horas_semana)
  `);

  const usuarios = [
    { nombre: 'Laura Gómez (Admin)', email: 'admin@turnos.com', password: hash('admin123'), rol: 'admin', puesto: 'supervisor', max_horas_semana: 42 },
    { nombre: 'Carlos Pérez', email: 'carlos@turnos.com', password: hash('empleado123'), rol: 'empleado', puesto: 'mesero', max_horas_semana: 42 },
    { nombre: 'María Rodríguez', email: 'maria@turnos.com', password: hash('empleado123'), rol: 'empleado', puesto: 'mesero', max_horas_semana: 42 },
    { nombre: 'Andrés Torres', email: 'andres@turnos.com', password: hash('empleado123'), rol: 'empleado', puesto: 'cocinero', max_horas_semana: 42 },
    { nombre: 'Juliana Ríos', email: 'juliana@turnos.com', password: hash('empleado123'), rol: 'empleado', puesto: 'cocinero', max_horas_semana: 42 },
    { nombre: 'Pedro Salazar', email: 'pedro@turnos.com', password: hash('empleado123'), rol: 'empleado', puesto: 'cajero', max_horas_semana: 42 },
  ];
  const info = usuarios.map(u => insertUser.run(u));
  const ids = info.map(i => i.lastInsertRowid); // [admin, carlos, maria, andres, juliana, pedro]

  const HORAS = {
    'mañana': ['06:00', '14:00'],
    'tarde': ['14:00', '22:00'],
    'noche': ['22:00', '06:00'],
  };

  const insertTurno = db.prepare(`
    INSERT INTO turnos (fecha, tipo_turno, hora_inicio, hora_fin, puesto_requerido, cantidad_requerida)
    VALUES (@fecha, @tipo_turno, @hora_inicio, @hora_fin, @puesto_requerido, @cantidad_requerida)
  `);
  const insertAsig = db.prepare(`
    INSERT INTO asignaciones (turno_id, usuario_id, estado, origen) VALUES (?, ?, 'asignado', 'manual')
  `);

  // Genera turnos para los próximos 7 días para mesero/cocinero/cajero en mañana y tarde
  const hoy = new Date();
  const puestos = ['mesero', 'cocinero', 'cajero'];
  const asignablesPorPuesto = {
    mesero: [ids[1], ids[2]],
    cocinero: [ids[3], ids[4]],
    cajero: [ids[5]],
  };

  for (let d = 0; d < 7; d++) {
    const fecha = new Date(hoy);
    fecha.setDate(hoy.getDate() + d);
    const fechaStr = fecha.toISOString().slice(0, 10);

    ['mañana', 'tarde'].forEach((tipo) => {
      puestos.forEach((puesto) => {
        const [inicio, fin] = HORAS[tipo];
        const r = insertTurno.run({
          fecha: fechaStr,
          tipo_turno: tipo,
          hora_inicio: inicio,
          hora_fin: fin,
          puesto_requerido: puesto,
          cantidad_requerida: 1,
        });
        // Asigna automáticamente al primer día como ejemplo
        if (d < 3) {
          const candidatos = asignablesPorPuesto[puesto];
          const elegido = candidatos[d % candidatos.length];
          insertAsig.run(r.lastInsertRowid, elegido);
        }
      });
    });
  }

  console.log('✔ Base de datos inicializada con datos de ejemplo.');
  console.log('  Admin:    admin@turnos.com / admin123');
  console.log('  Empleado: carlos@turnos.com / empleado123 (y otros, ver README)');
}

seed();

module.exports = db;