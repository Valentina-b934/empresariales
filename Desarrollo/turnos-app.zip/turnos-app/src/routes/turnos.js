// src/routes/turnos.js
const express = require('express');
const db = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');
const { validarAsignacionCompleta } = require('../utils/reglasNegocio');
const { notificar } = require('../utils/notificaciones');

const router = express.Router();

// --- Crear turno (definición de puesto/turno requerido) --------------------
router.post('/', requireAuth, requireRole('admin'), (req, res) => {
  const { fecha, tipo_turno, hora_inicio, hora_fin, puesto_requerido, cantidad_requerida, notas } = req.body;
  if (!fecha || !tipo_turno || !hora_inicio || !hora_fin || !puesto_requerido) {
    return res.status(400).json({ error: 'Faltan campos obligatorios del turno.' });
  }
  try {
    const info = db.prepare(`
      INSERT INTO turnos (fecha, tipo_turno, hora_inicio, hora_fin, puesto_requerido, cantidad_requerida, notas)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(fecha, tipo_turno, hora_inicio, hora_fin, puesto_requerido, cantidad_requerida || 1, notas || null);
    res.status(201).json({ id: info.lastInsertRowid });
  } catch (err) {
    if (String(err.message).includes('UNIQUE')) {
      return res.status(409).json({ error: 'Ya existe un turno con esa fecha, tipo y puesto.' });
    }
    res.status(500).json({ error: 'Error creando el turno.' });
  }
});

// --- Listado / calendario ---------------------------------------------------
router.get('/', requireAuth, (req, res) => {
  const { desde, hasta, puesto } = req.query;
  let sql = `
    SELECT t.*,
      (SELECT COUNT(*) FROM asignaciones a WHERE a.turno_id = t.id AND a.estado IN ('asignado','cubierto')) AS cubiertos
    FROM turnos t WHERE 1=1
  `;
  const params = [];
  if (desde) { sql += ' AND t.fecha >= ?'; params.push(desde); }
  if (hasta) { sql += ' AND t.fecha <= ?'; params.push(hasta); }
  if (puesto) { sql += ' AND t.puesto_requerido = ?'; params.push(puesto); }
  sql += ' ORDER BY t.fecha, t.tipo_turno';

  const turnos = db.prepare(sql).all(...params);

  const asigStmt = db.prepare(`
    SELECT a.id, a.usuario_id, a.estado, u.nombre, u.puesto
    FROM asignaciones a JOIN usuarios u ON u.id = a.usuario_id
    WHERE a.turno_id = ?
  `);
  const resultado = turnos.map(t => ({
    ...t,
    asignaciones: asigStmt.all(t.id),
    estado_cobertura: t.cubiertos >= t.cantidad_requerida ? 'cubierto' : 'pendiente',
  }));

  res.json(resultado);
});

router.get('/mios', requireAuth, (req, res) => {
  const turnos = db.prepare(`
    SELECT t.*, a.id AS asignacion_id, a.estado AS estado_asignacion
    FROM asignaciones a
    JOIN turnos t ON t.id = a.turno_id
    WHERE a.usuario_id = ? AND a.estado IN ('asignado','cubierto','publicado')
    ORDER BY t.fecha, t.tipo_turno
  `).all(req.user.id);
  res.json(turnos);
});

// --- Asignación manual por el admin ----------------------------------------
router.post('/:id/asignar', requireAuth, requireRole('admin'), (req, res) => {
  const turno = db.prepare('SELECT * FROM turnos WHERE id = ?').get(req.params.id);
  if (!turno) return res.status(404).json({ error: 'Turno no encontrado.' });

  const { usuario_id } = req.body;
  const usuario = db.prepare('SELECT * FROM usuarios WHERE id = ? AND activo = 1').get(usuario_id);
  if (!usuario) return res.status(404).json({ error: 'Empleado no encontrado o inactivo.' });

  try {
    validarAsignacionCompleta(usuario, turno);
  } catch (err) {
    return res.status(422).json({ error: err.message, codigo: err.codigo });
  }

  try {
    const info = db.prepare(`
      INSERT INTO asignaciones (turno_id, usuario_id, estado, origen) VALUES (?, ?, 'asignado', 'manual')
    `).run(turno.id, usuario.id);

    notificar(usuario.id, 'turno_asignado',
      `Se te asignó el turno de ${turno.tipo_turno} el ${turno.fecha} (${turno.hora_inicio}-${turno.hora_fin}) como ${turno.puesto_requerido}.`,
      { turno_id: turno.id });

    res.status(201).json({ id: info.lastInsertRowid });
  } catch (err) {
    if (String(err.message).includes('UNIQUE')) {
      return res.status(409).json({ error: 'Este empleado ya está asignado a este turno.' });
    }
    res.status(500).json({ error: 'Error asignando el turno.' });
  }
});

// --- Distribución automática sugerida ---------------------------------------
// Estrategia: para cada turno con cupos libres, entre los empleados con el
// puesto correcto y disponibilidad marcada para esa fecha/tipo_turno, elige
// primero a quien tenga MENOS horas asignadas esa semana (balancea la carga),
// validando siempre horas máximas y cruces.
router.post('/generar-automatico', requireAuth, requireRole('admin'), (req, res) => {
  const { desde, hasta } = req.body;
  if (!desde || !hasta) return res.status(400).json({ error: 'Debes indicar rango desde/hasta.' });

  const turnos = db.prepare(`
    SELECT t.*,
      (SELECT COUNT(*) FROM asignaciones a WHERE a.turno_id = t.id AND a.estado IN ('asignado','cubierto')) AS cubiertos
    FROM turnos t
    WHERE t.fecha BETWEEN ? AND ?
    ORDER BY t.fecha, t.tipo_turno
  `).all(desde, hasta);

  const resultados = [];

  for (const turno of turnos) {
    let faltantes = turno.cantidad_requerida - turno.cubiertos;
    if (faltantes <= 0) continue;

    const candidatos = db.prepare(`
      SELECT u.* FROM usuarios u
      JOIN disponibilidad d ON d.usuario_id = u.id
      WHERE u.puesto = ? AND u.activo = 1
        AND d.fecha = ? AND d.tipo_turno = ? AND d.disponible = 1
    `).all(turno.puesto_requerido, turno.fecha, turno.tipo_turno);

    // Ordena por horas ya asignadas esta semana (menor primero) => balanceo de carga
    const { horasAsignadasEnSemana } = require('../utils/reglasNegocio');
    candidatos.sort((a, b) =>
      horasAsignadasEnSemana(a.id, turno.fecha) - horasAsignadasEnSemana(b.id, turno.fecha)
    );

    for (const cand of candidatos) {
      if (faltantes <= 0) break;
      try {
        validarAsignacionCompleta(cand, turno);
      } catch {
        continue; // no cumple reglas, prueba con el siguiente candidato
      }
      // evita duplicar si ya estaba asignado
      const yaAsignado = db.prepare(
        'SELECT 1 FROM asignaciones WHERE turno_id = ? AND usuario_id = ?'
      ).get(turno.id, cand.id);
      if (yaAsignado) continue;

      db.prepare(`
        INSERT INTO asignaciones (turno_id, usuario_id, estado, origen) VALUES (?, ?, 'asignado', 'auto')
      `).run(turno.id, cand.id);

      notificar(cand.id, 'turno_asignado',
        `Se te asignó automáticamente el turno de ${turno.tipo_turno} el ${turno.fecha} (${turno.puesto_requerido}).`,
        { turno_id: turno.id });

      resultados.push({ turno_id: turno.id, usuario_id: cand.id, fecha: turno.fecha, tipo_turno: turno.tipo_turno });
      faltantes--;
    }
  }

  res.json({ asignaciones_creadas: resultados.length, detalle: resultados });
});

router.delete('/asignaciones/:id', requireAuth, requireRole('admin'), (req, res) => {
  const asig = db.prepare('SELECT * FROM asignaciones WHERE id = ?').get(req.params.id);
  if (!asig) return res.status(404).json({ error: 'Asignación no encontrada.' });
  db.prepare('DELETE FROM asignaciones WHERE id = ?').run(req.params.id);
  notificar(asig.usuario_id, 'info', 'Se canceló una de tus asignaciones de turno.', { asignacion_id: asig.id });
  res.json({ ok: true });
});

module.exports = router;
