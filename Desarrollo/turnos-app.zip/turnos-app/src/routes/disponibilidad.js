// src/routes/disponibilidad.js
const express = require('express');
const db = require('../db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

// El empleado marca/actualiza su disponibilidad para una fecha + tipo_turno
router.post('/', requireAuth, (req, res) => {
  const { fecha, tipo_turno, disponible } = req.body;
  if (!fecha || !tipo_turno) return res.status(400).json({ error: 'Faltan fecha o tipo_turno.' });

  db.prepare(`
    INSERT INTO disponibilidad (usuario_id, fecha, tipo_turno, disponible)
    VALUES (?, ?, ?, ?)
    ON CONFLICT(usuario_id, fecha, tipo_turno)
    DO UPDATE SET disponible = excluded.disponible
  `).run(req.user.id, fecha, tipo_turno, disponible ? 1 : 0);

  res.json({ ok: true });
});

// Carga masiva (marcar toda la semana de una vez desde el formulario)
router.post('/lote', requireAuth, (req, res) => {
  const { items } = req.body; // [{fecha, tipo_turno, disponible}, ...]
  if (!Array.isArray(items)) return res.status(400).json({ error: 'Se espera un arreglo "items".' });

  const stmt = db.prepare(`
    INSERT INTO disponibilidad (usuario_id, fecha, tipo_turno, disponible)
    VALUES (?, ?, ?, ?)
    ON CONFLICT(usuario_id, fecha, tipo_turno)
    DO UPDATE SET disponible = excluded.disponible
  `);
  const tx = db.transaction((rows) => {
    for (const it of rows) stmt.run(req.user.id, it.fecha, it.tipo_turno, it.disponible ? 1 : 0);
  });
  tx(items);

  res.json({ ok: true, guardados: items.length });
});

router.get('/mia', requireAuth, (req, res) => {
  const { desde, hasta } = req.query;
  let sql = 'SELECT * FROM disponibilidad WHERE usuario_id = ?';
  const params = [req.user.id];
  if (desde) { sql += ' AND fecha >= ?'; params.push(desde); }
  if (hasta) { sql += ' AND fecha <= ?'; params.push(hasta); }
  res.json(db.prepare(sql).all(...params));
});

module.exports = router;
