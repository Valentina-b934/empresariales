// src/routes/notificaciones.js
const express = require('express');
const db = require('../db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

router.get('/', requireAuth, (req, res) => {
  const notis = db.prepare(
    'SELECT * FROM notificaciones WHERE usuario_id = ? ORDER BY creado_en DESC LIMIT 50'
  ).all(req.user.id);
  res.json(notis);
});

router.post('/:id/leida', requireAuth, (req, res) => {
  db.prepare('UPDATE notificaciones SET leida = 1 WHERE id = ? AND usuario_id = ?')
    .run(req.params.id, req.user.id);
  res.json({ ok: true });
});

router.post('/marcar-todas-leidas', requireAuth, (req, res) => {
  db.prepare('UPDATE notificaciones SET leida = 1 WHERE usuario_id = ?').run(req.user.id);
  res.json({ ok: true });
});

module.exports = router;
