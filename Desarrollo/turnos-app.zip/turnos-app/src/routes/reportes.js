// src/routes/reportes.js
const express = require('express');
const db = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');
const { horasAsignadasEnSemana, inicioSemanaISO } = require('../utils/reglasNegocio');

const router = express.Router();

// Cobertura de turnos en un rango (cuántos quedaron cubiertos vs pendientes)
router.get('/cobertura', requireAuth, requireRole('admin'), (req, res) => {
  const { desde, hasta } = req.query;
  const turnos = db.prepare(`
    SELECT t.*,
      (SELECT COUNT(*) FROM asignaciones a WHERE a.turno_id = t.id AND a.estado IN ('asignado','cubierto')) AS cubiertos
    FROM turnos t
    WHERE t.fecha BETWEEN ? AND ?
  `).all(desde || '0000-01-01', hasta || '9999-12-31');

  const total = turnos.length;
  const cubiertos = turnos.filter(t => t.cubiertos >= t.cantidad_requerida).length;
  const pendientes = total - cubiertos;

  res.json({
    total,
    cubiertos,
    pendientes,
    porcentaje_cobertura: total ? Math.round((cubiertos / total) * 100) : 100,
    turnos_pendientes: turnos.filter(t => t.cubiertos < t.cantidad_requerida)
      .map(t => ({ id: t.id, fecha: t.fecha, tipo_turno: t.tipo_turno, puesto_requerido: t.puesto_requerido,
                   faltan: t.cantidad_requerida - t.cubiertos })),
  });
});

// Ranking de quién más publica / toma turnos intercambiados
router.get('/intercambios', requireAuth, requireRole('admin'), (req, res) => {
  const publicaciones = db.prepare(`
    SELECT u.id, u.nombre, COUNT(*) AS total_publicados
    FROM intercambios i JOIN usuarios u ON u.id = i.solicitado_por
    GROUP BY u.id ORDER BY total_publicados DESC
  `).all();

  const aceptaciones = db.prepare(`
    SELECT u.id, u.nombre, COUNT(*) AS total_tomados
    FROM intercambios i JOIN usuarios u ON u.id = i.aceptado_por
    WHERE i.aceptado_por IS NOT NULL
    GROUP BY u.id ORDER BY total_tomados DESC
  `).all();

  const pendientes = db.prepare(`SELECT COUNT(*) AS n FROM intercambios WHERE estado = 'pendiente'`).get().n;

  res.json({ publicaciones, aceptaciones, intercambios_pendientes: pendientes });
});

// Horas semanales por empleado (para validar cumplimiento del límite legal)
router.get('/horas-semana', requireAuth, requireRole('admin'), (req, res) => {
  const { fecha } = req.query; // cualquier fecha dentro de la semana a consultar
  const ref = fecha || new Date().toISOString().slice(0, 10);
  const inicio = inicioSemanaISO(ref);

  const empleados = db.prepare(`SELECT * FROM usuarios WHERE rol = 'empleado' AND activo = 1`).all();
  const reporte = empleados.map(e => {
    const horas = horasAsignadasEnSemana(e.id, ref);
    return {
      id: e.id,
      nombre: e.nombre,
      puesto: e.puesto,
      horas_asignadas: Math.round(horas * 10) / 10,
      maximo_legal: e.max_horas_semana,
      excede: horas > e.max_horas_semana,
    };
  });

  res.json({ semana_inicio: inicio, empleados: reporte });
});

module.exports = router;
