// src/routes/auth.js
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../db');
const { requireAuth, requireRole, JWT_SECRET } = require('../middleware/auth');

const router = express.Router();
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '8h';

router.post('/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'Email y password son obligatorios.' });
  }

  const usuario = db.prepare('SELECT * FROM usuarios WHERE email = ? AND activo = 1').get(email);
  if (!usuario) return res.status(401).json({ error: 'Credenciales inválidas.' });

  const ok = bcrypt.compareSync(password, usuario.password);
  if (!ok) return res.status(401).json({ error: 'Credenciales inválidas.' });

  const payload = {
    id: usuario.id,
    nombre: usuario.nombre,
    email: usuario.email,
    rol: usuario.rol,
    puesto: usuario.puesto,
  };
  const token = jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });

  res.json({ token, usuario: payload });
});

router.get('/me', requireAuth, (req, res) => {
  const usuario = db.prepare(
    'SELECT id, nombre, email, rol, puesto, max_horas_semana FROM usuarios WHERE id = ?'
  ).get(req.user.id);
  res.json(usuario);
});

// Admin: crear empleados
router.post('/usuarios', requireAuth, requireRole('admin'), (req, res) => {
  const { nombre, email, password, rol, puesto, max_horas_semana } = req.body;
  if (!nombre || !email || !password || !rol || !puesto) {
    return res.status(400).json({ error: 'Faltan campos obligatorios.' });
  }
  if (!['admin', 'empleado'].includes(rol)) {
    return res.status(400).json({ error: 'Rol inválido.' });
  }
  try {
    const hash = bcrypt.hashSync(password, 10);
    const info = db.prepare(`
      INSERT INTO usuarios (nombre, email, password, rol, puesto, max_horas_semana)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(nombre, email, hash, rol, puesto, max_horas_semana || 42);
    res.status(201).json({ id: info.lastInsertRowid });
  } catch (err) {
    if (String(err.message).includes('UNIQUE')) {
      return res.status(409).json({ error: 'Ya existe un usuario con ese email.' });
    }
    res.status(500).json({ error: 'Error creando usuario.' });
  }
});

router.get('/usuarios', requireAuth, requireRole('admin'), (req, res) => {
  const usuarios = db.prepare(
    'SELECT id, nombre, email, rol, puesto, max_horas_semana, activo FROM usuarios ORDER BY nombre'
  ).all();
  res.json(usuarios);
});

router.patch('/usuarios/:id/activo', requireAuth, requireRole('admin'), (req, res) => {
  const { activo } = req.body;
  db.prepare('UPDATE usuarios SET activo = ? WHERE id = ?').run(activo ? 1 : 0, req.params.id);
  res.json({ ok: true });
});

module.exports = router;
