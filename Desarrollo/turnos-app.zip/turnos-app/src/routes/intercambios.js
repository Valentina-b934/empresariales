// src/routes/intercambios.js
// Flujo de intercambio automático:
// 1) Un empleado "publica" una asignación suya (no puede ir a su turno).
// 2) Todos los empleados con el MISMO puesto/capacitación que estén activos
//    reciben notificación en tiempo real de que hay un turno disponible.
// 3) El primero en aceptar se queda con el turno (regla "first-come"), siempre
//    que pase las validaciones de horas máximas y cruces de horario.
// 4) El supervisor recibe notificación del cambio ya resuelto, sin mediar.

const express = require('express');
const db = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');
const { validarAsignacionCompleta } = require('../utils/reglasNegocio');
const { notificar, notificarMuchos } = require('../utils/notificaciones');

const router = express.Router();

// --- Publicar un turno propio para intercambio ------------------------------
router.post('/publicar', requireAuth, (req, res) => {
  const { asignacion_id, motivo } = req.body;

  const asignacion = db.prepare('SELECT * FROM asignaciones WHERE id = ?').get(asignacion_id);
  if (!asignacion) return res.status(404).json({ error: 'Asignación no encontrada.' });

  // Un empleado solo puede publicar SUS PROPIAS asignaciones (el admin puede forzar cualquiera)
  if (req.user.rol !== 'admin' && asignacion.usuario_id !== req.user.id) {
    return res.status(403).json({ error: 'Solo puedes publicar tus propios turnos.' });
  }
  if (asignacion.estado !== 'asignado') {
    return res.status(409).json({ error: `La asignación ya está en estado "${asignacion.estado}".` });
  }

  const yaPublicado = db.prepare(
    `SELECT 1 FROM intercambios WHERE asignacion_id = ? AND estado = 'pendiente'`
  ).get(asignacion_id);
  if (yaPublicado) return res.status(409).json({ error: 'Este turno ya está publicado para intercambio.' });

  const turno = db.prepare('SELECT * FROM turnos WHERE id = ?').get(asignacion.turno_id);

  const tx = db.transaction(() => {
    const info = db.prepare(`
      INSERT INTO intercambios (asignacion_id, solicitado_por, motivo)
      VALUES (?, ?, ?)
    `).run(asignacion_id, asignacion.usuario_id, motivo || null);

    db.prepare(`UPDATE asignaciones SET estado = 'publicado' WHERE id = ?`).run(asignacion_id);
    return info.lastInsertRowid;
  });
  const intercambioId = tx();

  // Notifica a todos los compañeros CALIFICADOS (mismo puesto), activos,
  // distintos del que publica, sin importar disponibilidad previa: ellos deciden.
  const elegibles = db.prepare(`
    SELECT id FROM usuarios
    WHERE puesto = ? AND activo = 1 AND rol = 'empleado' AND id != ?
  `).all(turno.puesto_requerido, asignacion.usuario_id);

  notificarMuchos(
    elegibles.map(u => u.id),
    'turno_publicado',
    `${turno.puesto_requerido} necesitado: turno de ${turno.tipo_turno} el ${turno.fecha} (${turno.hora_inicio}-${turno.hora_fin}) quedó disponible para cubrir.`,
    { intercambio_id: intercambioId, turno_id: turno.id }
  );

  res.status(201).json({ intercambio_id: intercambioId, notificados: elegibles.length });
});

// --- Ver turnos publicados que el usuario actual podría cubrir --------------
router.get('/disponibles', requireAuth, (req, res) => {
  const filas = db.prepare(`
    SELECT i.id AS intercambio_id, i.motivo, i.creado_en,
           t.id AS turno_id, t.fecha, t.tipo_turno, t.hora_inicio, t.hora_fin, t.puesto_requerido,
           u.nombre AS solicitante
    FROM intercambios i
    JOIN asignaciones a ON a.id = i.asignacion_id
    JOIN turnos t ON t.id = a.turno_id
    JOIN usuarios u ON u.id = i.solicitado_por
    WHERE i.estado = 'pendiente'
      AND t.puesto_requerido = ?
      AND i.solicitado_por != ?
    ORDER BY i.creado_en
  `).all(req.user.puesto, req.user.id);

  res.json(filas);
});

// --- Aceptar un intercambio (toma el turno) ---------------------------------
router.post('/:id/aceptar', requireAuth, (req, res) => {
  const intercambio = db.prepare('SELECT * FROM intercambios WHERE id = ?').get(req.params.id);
  if (!intercambio) return res.status(404).json({ error: 'Intercambio no encontrado.' });
  if (intercambio.estado !== 'pendiente') {
    return res.status(409).json({ error: 'Este turno ya fue tomado o cancelado por otro compañero.' });
  }
  if (intercambio.solicitado_por === req.user.id) {
    return res.status(400).json({ error: 'No puedes tomar tu propio turno publicado.' });
  }

  const asignacion = db.prepare('SELECT * FROM asignaciones WHERE id = ?').get(intercambio.asignacion_id);
  const turno = db.prepare('SELECT * FROM turnos WHERE id = ?').get(asignacion.turno_id);
  const usuarioNuevo = db.prepare('SELECT * FROM usuarios WHERE id = ? AND activo = 1').get(req.user.id);

  try {
    validarAsignacionCompleta(usuarioNuevo, turno, asignacion.id);
  } catch (err) {
    return res.status(422).json({ error: err.message, codigo: err.codigo });
  }

  // Transacción con bloqueo optimista: solo el primero que llega con
  // estado 'pendiente' logra el UPDATE (evita condiciones de carrera si dos
  // compañeros aceptan casi al mismo tiempo).
  const tx = db.transaction(() => {
    const cambios = db.prepare(
      `UPDATE intercambios SET estado = 'aceptado', aceptado_por = ?, resuelto_en = datetime('now')
       WHERE id = ? AND estado = 'pendiente'`
    ).run(req.user.id, intercambio.id);

    if (cambios.changes === 0) {
      return { exito: false };
    }

    // El turno pasa del empleado original al nuevo empleado
    db.prepare(`UPDATE asignaciones SET usuario_id = ?, estado = 'cubierto', origen = 'intercambio' WHERE id = ?`)
      .run(req.user.id, asignacion.id);

    return { exito: true };
  });

  const resultado = tx();
  if (!resultado.exito) {
    return res.status(409).json({ error: 'Otro compañero ya tomó este turno un instante antes.' });
  }

  // Notifica al que publicó que ya tiene reemplazo
  notificar(intercambio.solicitado_por, 'intercambio_aceptado',
    `${usuarioNuevo.nombre} tomó tu turno de ${turno.tipo_turno} el ${turno.fecha}. Ya no debes asistir.`,
    { turno_id: turno.id });

  // Notifica a TODOS los admins: el cambio ya quedó resuelto, sin mediar
  const admins = db.prepare(`SELECT id FROM usuarios WHERE rol = 'admin' AND activo = 1`).all();
  notificarMuchos(admins.map(a => a.id), 'turno_cubierto',
    `Intercambio resuelto automáticamente: ${usuarioNuevo.nombre} cubrirá el turno de ${turno.tipo_turno} del ${turno.fecha} en lugar del solicitante original.`,
    { turno_id: turno.id, intercambio_id: intercambio.id });

  res.json({ ok: true, turno_id: turno.id });
});

// --- Cancelar una publicación propia (el empleado se arrepiente) -----------
router.post('/:id/cancelar', requireAuth, (req, res) => {
  const intercambio = db.prepare('SELECT * FROM intercambios WHERE id = ?').get(req.params.id);
  if (!intercambio) return res.status(404).json({ error: 'Intercambio no encontrado.' });
  if (intercambio.estado !== 'pendiente') {
    return res.status(409).json({ error: 'Este intercambio ya no está pendiente.' });
  }
  if (req.user.rol !== 'admin' && intercambio.solicitado_por !== req.user.id) {
    return res.status(403).json({ error: 'Solo el solicitante o un admin puede cancelar esta publicación.' });
  }

  db.prepare(`UPDATE intercambios SET estado = 'cancelado', resuelto_en = datetime('now') WHERE id = ?`)
    .run(intercambio.id);
  db.prepare(`UPDATE asignaciones SET estado = 'asignado' WHERE id = ?`).run(intercambio.asignacion_id);

  res.json({ ok: true });
});

// --- Historial (para reportes / admin) --------------------------------------
router.get('/historial', requireAuth, requireRole('admin'), (req, res) => {
  const filas = db.prepare(`
    SELECT i.*, t.fecha, t.tipo_turno, t.puesto_requerido,
           us.nombre AS solicitante, ua.nombre AS aceptado_por_nombre
    FROM intercambios i
    JOIN asignaciones a ON a.id = i.asignacion_id
    JOIN turnos t ON t.id = a.turno_id
    JOIN usuarios us ON us.id = i.solicitado_por
    LEFT JOIN usuarios ua ON ua.id = i.aceptado_por
    ORDER BY i.creado_en DESC
  `).all();
  res.json(filas);
});

module.exports = router;
