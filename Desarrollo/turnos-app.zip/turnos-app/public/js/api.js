// public/js/api.js
const Api = (() => {
  function token() { return localStorage.getItem('token'); }
  function usuario() {
    try { return JSON.parse(localStorage.getItem('usuario')); } catch { return null; }
  }
  function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('usuario');
    window.location.href = '/index.html';
  }

  async function req(method, path, body) {
    const res = await fetch(`/api${path}`, {
      method,
      headers: {
        'Content-Type': 'application/json',
        ...(token() ? { Authorization: `Bearer ${token()}` } : {}),
      },
      body: body ? JSON.stringify(body) : undefined,
    });

    if (res.status === 401) {
      logout();
      throw new Error('Sesión expirada.');
    }

    let data = null;
    try { data = await res.json(); } catch { /* respuesta vacía */ }

    if (!res.ok) {
      throw new Error((data && data.error) || `Error ${res.status}`);
    }
    return data;
  }

  return {
    get: (path) => req('GET', path),
    post: (path, body) => req('POST', path, body),
    patch: (path, body) => req('PATCH', path, body),
    delete: (path) => req('DELETE', path),
    token, usuario, logout,
  };
})();
