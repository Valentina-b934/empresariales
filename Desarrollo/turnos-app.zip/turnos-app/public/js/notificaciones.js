// public/js/notificaciones.js
// Maneja el socket en tiempo real, el panel de campana y los toasts.

const Notif = (() => {
  let socket = null;

  function toast(mensaje) {
    let wrap = document.querySelector('.toast-wrap');
    if (!wrap) {
      wrap = document.createElement('div');
      wrap.className = 'toast-wrap';
      document.body.appendChild(wrap);
    }
    const el = document.createElement('div');
    el.className = 'toast';
    el.textContent = mensaje;
    wrap.appendChild(el);
    setTimeout(() => el.remove(), 6000);
  }

  function timeAgo(iso) {
    const diffMs = Date.now() - new Date(iso.replace(' ', 'T') + 'Z').getTime();
    const min = Math.round(diffMs / 60000);
    if (min < 1) return 'ahora mismo';
    if (min < 60) return `hace ${min} min`;
    const h = Math.round(min / 60);
    if (h < 24) return `hace ${h} h`;
    return `hace ${Math.round(h / 24)} d`;
  }

  async function renderPanel() {
    const list = document.getElementById('noti-list');
    const countEl = document.getElementById('noti-count');
    if (!list) return;
    const notis = await Api.get('/notificaciones');
    const noLeidas = notis.filter(n => !n.leida).length;

    if (countEl) {
      countEl.textContent = noLeidas;
      countEl.style.display = noLeidas ? 'inline-block' : 'none';
    }

    list.innerHTML = notis.length
      ? notis.map(n => `
        <div class="noti-item ${n.leida ? '' : 'unread'}" data-id="${n.id}">
          <div>${n.mensaje}</div>
          <div class="when">${timeAgo(n.creado_en)}</div>
        </div>
      `).join('')
      : '<div class="noti-empty">No tienes notificaciones.</div>';
  }

  function initBell() {
    const bell = document.getElementById('noti-bell');
    const panel = document.getElementById('noti-panel');
    if (!bell || !panel) return;

    bell.addEventListener('click', async (e) => {
      e.stopPropagation();
      panel.classList.toggle('open');
      if (panel.classList.contains('open')) {
        await renderPanel();
        await Api.post('/notificaciones/marcar-todas-leidas');
        setTimeout(renderPanel, 400);
      }
    });
    document.addEventListener('click', (e) => {
      if (!panel.contains(e.target) && !bell.contains(e.target)) panel.classList.remove('open');
    });

    renderPanel();
  }

  function connect(onNotificacion) {
    if (!window.io) return; // socket.io no cargó (offline), la app sigue funcionando sin tiempo real
    socket = io({ auth: { token: Api.token() } });
    socket.on('notificacion', (noti) => {
      toast(noti.mensaje);
      renderPanel();
      if (typeof onNotificacion === 'function') onNotificacion(noti);
    });
  }

  return { connect, initBell, toast, renderPanel };
})();
