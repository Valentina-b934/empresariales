// public/js/employee.js
(function guard() {
  const u = Api.usuario();
  if (!Api.token() || !u) { window.location.href = '/index.html'; return; }
  if (u.rol !== 'empleado') { window.location.href = '/admin.html'; return; }
})();

const usuario = Api.usuario();
document.getElementById('nombre-usuario').textContent = usuario.nombre;
document.getElementById('puesto-usuario').textContent = usuario.puesto;
document.getElementById('btn-logout').addEventListener('click', Api.logout);

// --- Tabs --------------------------------------------------------------
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById(`panel-${btn.dataset.tab}`).classList.add('active');
    if (btn.dataset.tab === 'disponibles') cargarDisponibles();
    if (btn.dataset.tab === 'mis-turnos') cargarMisTurnos();
  });
});

const DIAS = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];
function fmtFecha(f) {
  const d = new Date(f + 'T00:00:00');
  return `${DIAS[d.getDay()]} ${d.getDate()}/${d.getMonth() + 1}`;
}

// --- Mis turnos ----------------------------------------------------------
async function cargarMisTurnos() {
  const cont = document.getElementById('lista-mis-turnos');
  const turnos = await Api.get('/turnos/mios');
  if (!turnos.length) {
    cont.innerHTML = '<p class="muted">No tienes turnos asignados por ahora.</p>';
    return;
  }
  cont.innerHTML = turnos.map(t => `
    <div class="shift-row">
      <div class="shift-info">
        <span class="date">${fmtFecha(t.fecha)} <span class="badge ${t.tipo_turno}">${t.tipo_turno}</span></span>
        <span class="meta">${t.hora_inicio} - ${t.hora_fin} · ${t.puesto_requerido}</span>
      </div>
      <div>
        ${t.estado_asignacion === 'publicado'
          ? '<span class="badge publicado">Publicado, esperando reemplazo</span>'
          : `<button class="btn secondary small" data-publicar="${t.asignacion_id}">No puedo asistir</button>`}
      </div>
    </div>
  `).join('');

  cont.querySelectorAll('[data-publicar]').forEach(btn => {
    btn.addEventListener('click', async () => {
      if (!confirm('¿Publicar este turno para que un compañero lo tome?')) return;
      btn.disabled = true;
      try {
        const r = await Api.post('/intercambios/publicar', { asignacion_id: Number(btn.dataset.publicar) });
        Notif.toast(`Turno publicado. Se notificó a ${r.notificados} compañero(s) calificado(s).`);
        cargarMisTurnos();
      } catch (err) {
        alert(err.message);
        btn.disabled = false;
      }
    });
  });
}

// --- Turnos disponibles para tomar ---------------------------------------
async function cargarDisponibles() {
  const cont = document.getElementById('lista-disponibles');
  const items = await Api.get('/intercambios/disponibles');
  if (!items.length) {
    cont.innerHTML = '<p class="muted">No hay turnos publicados para tu puesto en este momento.</p>';
    return;
  }
  cont.innerHTML = items.map(t => `
    <div class="shift-row">
      <div class="shift-info">
        <span class="date">${fmtFecha(t.fecha)} <span class="badge ${t.tipo_turno}">${t.tipo_turno}</span></span>
        <span class="meta">${t.hora_inicio} - ${t.hora_fin} · ${t.puesto_requerido} · publicado por ${t.solicitante}</span>
      </div>
      <button class="btn success small" data-aceptar="${t.intercambio_id}">Tomar turno</button>
    </div>
  `).join('');

  cont.querySelectorAll('[data-aceptar]').forEach(btn => {
    btn.addEventListener('click', async () => {
      btn.disabled = true;
      try {
        await Api.post(`/intercambios/${btn.dataset.aceptar}/aceptar`);
        Notif.toast('¡Turno tomado! Ya aparece en "Mis turnos".');
        cargarDisponibles();
        cargarMisTurnos();
      } catch (err) {
        alert(err.message);
        btn.disabled = false;
      }
    });
  });
}

// --- Disponibilidad --------------------------------------------------------
const TIPOS = ['mañana', 'tarde', 'noche'];
let diasDisponibilidad = [];

async function cargarDisponibilidad() {
  const cont = document.getElementById('tabla-disponibilidad');
  const hoy = new Date();
  diasDisponibilidad = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(hoy);
    d.setDate(hoy.getDate() + i);
    return d.toISOString().slice(0, 10);
  });

  const desde = diasDisponibilidad[0];
  const hasta = diasDisponibilidad[diasDisponibilidad.length - 1];
  const actuales = await Api.get(`/disponibilidad/mia?desde=${desde}&hasta=${hasta}`);
  const mapa = {};
  actuales.forEach(a => { mapa[`${a.fecha}_${a.tipo_turno}`] = !!a.disponible; });

  let html = '<table class="avail-table"><thead><tr><th>Día</th>' +
    TIPOS.map(t => `<th>${t}</th>`).join('') + '</tr></thead><tbody>';
  diasDisponibilidad.forEach(f => {
    html += `<tr><td>${fmtFecha(f)}</td>`;
    TIPOS.forEach(t => {
      const key = `${f}_${t}`;
      const checked = mapa[key] ? 'checked' : '';
      html += `<td><input type="checkbox" data-fecha="${f}" data-tipo="${t}" ${checked}/></td>`;
    });
    html += '</tr>';
  });
  html += '</tbody></table>';
  cont.innerHTML = html;
}

document.getElementById('btn-guardar-disp').addEventListener('click', async () => {
  const checkboxes = document.querySelectorAll('#tabla-disponibilidad input[type=checkbox]');
  const items = Array.from(checkboxes).map(cb => ({
    fecha: cb.dataset.fecha,
    tipo_turno: cb.dataset.tipo,
    disponible: cb.checked ? 1 : 0,
  }));
  const msg = document.getElementById('disp-msg');
  try {
    await Api.post('/disponibilidad/lote', { items });
    msg.className = 'ok-msg';
    msg.textContent = 'Disponibilidad guardada correctamente.';
  } catch (err) {
    msg.className = 'error-msg';
    msg.textContent = err.message;
  }
  setTimeout(() => { msg.textContent = ''; }, 3000);
});

// --- Init --------------------------------------------------------------
Notif.initBell();
Notif.connect(() => { cargarMisTurnos(); cargarDisponibles(); });
cargarMisTurnos();
cargarDisponibilidad();
