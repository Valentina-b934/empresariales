// public/js/admin.js
(function guard() {
  const u = Api.usuario();
  if (!Api.token() || !u) { window.location.href = '/index.html'; return; }
  if (u.rol !== 'admin') { window.location.href = '/employee.html'; return; }
})();

const usuario = Api.usuario();
document.getElementById('nombre-usuario').textContent = usuario.nombre;
document.getElementById('btn-logout').addEventListener('click', Api.logout);

// --- Tabs --------------------------------------------------------------
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById(`panel-${btn.dataset.tab}`).classList.add('active');
    const tab = btn.dataset.tab;
    if (tab === 'calendario') cargarTurnos();
    if (tab === 'empleados') cargarEmpleados();
    if (tab === 'intercambios') cargarIntercambios();
    if (tab === 'reportes') { cargarReporteHoras(); cargarReporteIntercambios(); }
  });
});

const DIAS = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];
function fmtFecha(f) {
  const d = new Date(f + 'T00:00:00');
  return `${DIAS[d.getDay()]} ${d.getDate()}/${d.getMonth() + 1}`;
}
function hoyISO(offset = 0) {
  const d = new Date(); d.setDate(d.getDate() + offset);
  return d.toISOString().slice(0, 10);
}

// Rango por defecto: próximos 14 días
document.getElementById('filtro-desde').value = hoyISO(0);
document.getElementById('filtro-hasta').value = hoyISO(14);
document.getElementById('auto-desde').value = hoyISO(0);
document.getElementById('auto-hasta').value = hoyISO(7);
document.getElementById('rep-desde').value = hoyISO(0);
document.getElementById('rep-hasta').value = hoyISO(14);

// --- Crear turno ---------------------------------------------------------
document.getElementById('form-turno').addEventListener('submit', async (e) => {
  e.preventDefault();
  const msg = document.getElementById('turno-msg');
  msg.textContent = '';
  try {
    await Api.post('/turnos', {
      fecha: document.getElementById('t-fecha').value,
      tipo_turno: document.getElementById('t-tipo').value,
      hora_inicio: document.getElementById('t-inicio').value,
      hora_fin: document.getElementById('t-fin').value,
      puesto_requerido: document.getElementById('t-puesto').value.trim().toLowerCase(),
      cantidad_requerida: Number(document.getElementById('t-cantidad').value) || 1,
    });
    msg.className = 'ok-msg';
    msg.textContent = 'Turno creado.';
    document.getElementById('form-turno').reset();
    document.getElementById('t-cantidad').value = 1;
    cargarTurnos();
  } catch (err) {
    msg.className = 'error-msg';
    msg.textContent = err.message;
  }
});

// --- Distribución automática ----------------------------------------------
document.getElementById('btn-generar-auto').addEventListener('click', async () => {
  const msg = document.getElementById('auto-msg');
  msg.textContent = '';
  const desde = document.getElementById('auto-desde').value;
  const hasta = document.getElementById('auto-hasta').value;
  try {
    const r = await Api.post('/turnos/generar-automatico', { desde, hasta });
    msg.className = 'ok-msg';
    msg.textContent = `Se crearon ${r.asignaciones_creadas} asignaciones automáticas.`;
    cargarTurnos();
  } catch (err) {
    msg.className = 'error-msg';
    msg.textContent = err.message;
  }
});

// --- Listado de turnos -----------------------------------------------------
document.getElementById('btn-filtrar').addEventListener('click', cargarTurnos);

async function cargarTurnos() {
  const cont = document.getElementById('lista-turnos');
  const desde = document.getElementById('filtro-desde').value;
  const hasta = document.getElementById('filtro-hasta').value;
  const turnos = await Api.get(`/turnos?desde=${desde}&hasta=${hasta}`);

  if (!turnos.length) {
    cont.innerHTML = '<p class="muted">No hay turnos en este rango. Crea uno arriba.</p>';
    return;
  }

  cont.innerHTML = turnos.map(t => `
    <div class="shift-row">
      <div class="shift-info">
        <span class="date">${fmtFecha(t.fecha)} <span class="badge ${t.tipo_turno}">${t.tipo_turno}</span>
          <span class="badge ${t.estado_cobertura}">${t.estado_cobertura === 'cubierto' ? 'Cubierto' : 'Pendiente'}</span>
        </span>
        <span class="meta">${t.hora_inicio}-${t.hora_fin} · ${t.puesto_requerido} · requiere ${t.cantidad_requerida}, cubiertos ${t.cubiertos}</span>
        <span class="meta">${t.asignaciones.map(a => `${a.nombre} (${a.estado})`).join(', ') || 'Sin asignar'}</span>
      </div>
      <div style="display:flex; gap:6px; align-items:center;">
        <select data-empleado-para="${t.id}" data-puesto="${t.puesto_requerido}">
          <option value="">Asignar empleado...</option>
        </select>
        <button class="btn small" data-asignar="${t.id}">Asignar</button>
      </div>
    </div>
  `).join('');

  // Llena los selects con empleados que coinciden en puesto
  const empleados = await Api.get('/auth/usuarios');
  cont.querySelectorAll('select[data-empleado-para]').forEach(sel => {
    const puesto = sel.dataset.puesto;
    const candidatos = empleados.filter(e => e.rol === 'empleado' && e.puesto === puesto && e.activo);
    candidatos.forEach(c => {
      const opt = document.createElement('option');
      opt.value = c.id;
      opt.textContent = c.nombre;
      sel.appendChild(opt);
    });
  });

  cont.querySelectorAll('[data-asignar]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const turnoId = btn.dataset.asignar;
      const sel = cont.querySelector(`select[data-empleado-para="${turnoId}"]`);
      if (!sel.value) return alert('Selecciona un empleado.');
      try {
        await Api.post(`/turnos/${turnoId}/asignar`, { usuario_id: Number(sel.value) });
        Notif.toast('Empleado asignado.');
        cargarTurnos();
      } catch (err) {
        alert(err.message);
      }
    });
  });
}

// --- Empleados ---------------------------------------------------------
document.getElementById('form-empleado').addEventListener('submit', async (e) => {
  e.preventDefault();
  const msg = document.getElementById('empleado-msg');
  msg.textContent = '';
  try {
    await Api.post('/auth/usuarios', {
      nombre: document.getElementById('e-nombre').value.trim(),
      email: document.getElementById('e-email').value.trim(),
      password: document.getElementById('e-password').value,
      rol: document.getElementById('e-rol').value,
      puesto: document.getElementById('e-puesto').value.trim().toLowerCase(),
      max_horas_semana: Number(document.getElementById('e-maxhoras').value) || 42,
    });
    msg.className = 'ok-msg';
    msg.textContent = 'Empleado creado.';
    document.getElementById('form-empleado').reset();
    document.getElementById('e-maxhoras').value = 42;
    cargarEmpleados();
  } catch (err) {
    msg.className = 'error-msg';
    msg.textContent = err.message;
  }
});

async function cargarEmpleados() {
  const cont = document.getElementById('lista-empleados');
  const empleados = await Api.get('/auth/usuarios');
  cont.innerHTML = `
    <table class="simple">
      <thead><tr><th>Nombre</th><th>Correo</th><th>Rol</th><th>Puesto</th><th>Máx h/sem</th><th>Estado</th><th></th></tr></thead>
      <tbody>
        ${empleados.map(e => `
          <tr>
            <td>${e.nombre}</td><td>${e.email}</td><td>${e.rol}</td><td>${e.puesto}</td>
            <td>${e.max_horas_semana}</td>
            <td>${e.activo ? '<span class="badge cubierto">Activo</span>' : '<span class="badge pendiente">Inactivo</span>'}</td>
            <td><button class="btn secondary small" data-toggle="${e.id}" data-activo="${e.activo}">${e.activo ? 'Desactivar' : 'Activar'}</button></td>
          </tr>
        `).join('')}
      </tbody>
    </table>
  `;
  cont.querySelectorAll('[data-toggle]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const nuevoEstado = btn.dataset.activo === '1' ? 0 : 1;
      await Api.patch(`/auth/usuarios/${btn.dataset.toggle}/activo`, { activo: nuevoEstado });
      cargarEmpleados();
    });
  });
}

// --- Intercambios --------------------------------------------------------
async function cargarIntercambios() {
  const cont = document.getElementById('lista-intercambios');
  const items = await Api.get('/intercambios/historial');
  if (!items.length) {
    cont.innerHTML = '<p class="muted">Aún no hay intercambios registrados.</p>';
    return;
  }
  cont.innerHTML = `
    <table class="simple">
      <thead><tr><th>Fecha turno</th><th>Puesto</th><th>Solicitó</th><th>Tomó</th><th>Estado</th></tr></thead>
      <tbody>
        ${items.map(i => `
          <tr>
            <td>${fmtFecha(i.fecha)} (${i.tipo_turno})</td>
            <td>${i.puesto_requerido}</td>
            <td>${i.solicitante}</td>
            <td>${i.aceptado_por_nombre || '—'}</td>
            <td><span class="badge ${i.estado === 'aceptado' ? 'cubierto' : i.estado === 'pendiente' ? 'publicado' : 'pendiente'}">${i.estado}</span></td>
          </tr>
        `).join('')}
      </tbody>
    </table>
  `;
}

// --- Reportes --------------------------------------------------------------
document.getElementById('btn-rep-cobertura').addEventListener('click', async () => {
  const desde = document.getElementById('rep-desde').value;
  const hasta = document.getElementById('rep-hasta').value;
  const r = await Api.get(`/reportes/cobertura?desde=${desde}&hasta=${hasta}`);
  document.getElementById('rep-cobertura').innerHTML = `
    <div class="stat-row">
      <div class="stat-box"><div class="num">${r.total}</div><div class="label">Turnos totales</div></div>
      <div class="stat-box"><div class="num" style="color:var(--green)">${r.cubiertos}</div><div class="label">Cubiertos</div></div>
      <div class="stat-box"><div class="num" style="color:var(--red)">${r.pendientes}</div><div class="label">Pendientes</div></div>
      <div class="stat-box"><div class="num">${r.porcentaje_cobertura}%</div><div class="label">Cobertura</div></div>
    </div>
    ${r.turnos_pendientes.length ? `
      <table class="simple" style="margin-top:14px;">
        <thead><tr><th>Fecha</th><th>Turno</th><th>Puesto</th><th>Faltan</th></tr></thead>
        <tbody>${r.turnos_pendientes.map(t => `<tr><td>${fmtFecha(t.fecha)}</td><td>${t.tipo_turno}</td><td>${t.puesto_requerido}</td><td>${t.faltan}</td></tr>`).join('')}</tbody>
      </table>` : ''}
  `;
});

async function cargarReporteHoras() {
  const cont = document.getElementById('rep-horas');
  const r = await Api.get('/reportes/horas-semana');
  cont.innerHTML = `
    <p class="muted">Semana que inicia el ${fmtFecha(r.semana_inicio)}</p>
    <table class="simple">
      <thead><tr><th>Empleado</th><th>Puesto</th><th>Horas asignadas</th><th>Máximo legal</th><th></th></tr></thead>
      <tbody>
        ${r.empleados.map(e => `
          <tr>
            <td>${e.nombre}</td><td>${e.puesto}</td><td>${e.horas_asignadas} h</td><td>${e.maximo_legal} h</td>
            <td>${e.excede ? '<span class="badge pendiente">Excede</span>' : '<span class="badge cubierto">OK</span>'}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>
  `;
}

async function cargarReporteIntercambios() {
  const cont = document.getElementById('rep-intercambios');
  const r = await Api.get('/reportes/intercambios');
  cont.innerHTML = `
    <div class="grid-2">
      <div>
        <h4>Más publican turnos</h4>
        ${r.publicaciones.length ? `<table class="simple"><tbody>${r.publicaciones.map(p => `<tr><td>${p.nombre}</td><td>${p.total_publicados}</td></tr>`).join('')}</tbody></table>` : '<p class="muted">Sin datos.</p>'}
      </div>
      <div>
        <h4>Más toman turnos</h4>
        ${r.aceptaciones.length ? `<table class="simple"><tbody>${r.aceptaciones.map(p => `<tr><td>${p.nombre}</td><td>${p.total_tomados}</td></tr>`).join('')}</tbody></table>` : '<p class="muted">Sin datos.</p>'}
      </div>
    </div>
    <p class="muted" style="margin-top:10px;">Intercambios pendientes por resolver: ${r.intercambios_pendientes}</p>
  `;
}

// --- Init --------------------------------------------------------------
Notif.initBell();
Notif.connect(() => { cargarTurnos(); cargarIntercambios(); });
cargarTurnos();
