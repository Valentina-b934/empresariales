# Sistema de Asignación de Turnos con Intercambio Automático

Proyecto académico full-stack: backend en Node.js/Express con SQLite (sin
dependencias externas de base de datos) + frontend web (HTML/CSS/JS vanilla)
+ notificaciones en tiempo real con Socket.IO.

## Funcionalidades implementadas

- **Autenticación con roles** (admin / empleado) usando JWT.
- **Generación de horarios**: el admin crea turnos (mañana/tarde/noche) con
  puesto requerido y cantidad de personas necesarias.
- **Disponibilidad semanal**: cada empleado marca en qué turnos puede trabajar.
- **Distribución automática sugerida**: algoritmo que asigna empleados
  disponibles y calificados, balanceando la carga (prioriza a quien tiene
  menos horas asignadas esa semana), validando siempre las reglas de negocio.
- **Intercambio automático entre compañeros**:
  1. Un empleado publica una asignación que no puede cumplir.
  2. Todos los compañeros con el mismo puesto/capacitación reciben
     notificación push en tiempo real (WebSocket) + quedan registradas en su
     panel de notificaciones.
  3. El primero en aceptar se queda con el turno (regla "first-come"),
     siempre que pase las validaciones automáticas.
  4. El supervisor recibe notificación del cambio ya resuelto, sin mediar.
- **Reglas de negocio validadas en cada asignación/intercambio**:
  - Máximo de horas semanales por empleado (configurable por usuario;
    por defecto 42h, jornada máxima legal en Colombia vigente desde el 15 de
    julio de 2026 según la Ley 2101 de 2021 — ajústalo si tu negocio no aplica
    esa normativa).
  - Sin cruces de horario (un empleado no puede quedar en dos turnos que se
    solapen el mismo día).
  - Solo se permite cubrir turnos entre personas con el **mismo puesto o
    capacitación** (ej: un cocinero no puede cubrir a un mesero).
- **Panel de administrador**: calendario de turnos con estado de cobertura,
  gestión de empleados, historial de intercambios y reportes (cobertura,
  horas por empleado, ranking de quién más intercambia turnos).
- **Notificaciones**: persistidas en base de datos + push en vivo por
  WebSocket (campanita con contador de no leídas y toasts).

## Requisitos

- Node.js 18 o superior (probado con Node 22).
- No necesitas instalar ni configurar ningún motor de base de datos: usa
  SQLite en un archivo local (`data/turnos.db`), creado automáticamente.

## Instalación y ejecución

```bash
cd turnos-app
npm install
npm start
```

Abre tu navegador en **http://localhost:3000**

Al iniciar por primera vez, el sistema crea automáticamente la base de datos
con datos de ejemplo (usuarios y turnos de los próximos 7 días) para que
puedas probarlo de inmediato.

### Usuarios de prueba

| Rol      | Correo               | Contraseña   | Puesto   |
|----------|-----------------------|--------------|----------|
| Admin    | admin@turnos.com       | admin123     | supervisor |
| Empleado | carlos@turnos.com      | empleado123  | mesero   |
| Empleado | maria@turnos.com       | empleado123  | mesero   |
| Empleado | andres@turnos.com      | empleado123  | cocinero |
| Empleado | juliana@turnos.com     | empleado123  | cocinero |
| Empleado | pedro@turnos.com       | empleado123  | cajero   |

### Reiniciar los datos de ejemplo

```bash
npm run reset-db
```

Esto borra `data/turnos.db` y lo vuelve a crear con el seed inicial.

## Cómo probar el flujo de intercambio (lo más importante del proyecto)

1. Entra como **admin**, pestaña "Calendario", y confirma que hay turnos
   creados para los próximos días.
2. Abre otra ventana/incógnito y entra como **carlos@turnos.com**. En "Mis
   turnos" haz clic en **"No puedo asistir"** sobre alguno de sus turnos.
3. Abre otra ventana e ingresa como **maria@turnos.com** (mismo puesto:
   mesero). Verás la notificación en tiempo real (campanita/toast) y el turno
   aparecerá en la pestaña "Turnos disponibles para tomar". Haz clic en
   **"Tomar turno"**.
4. Vuelve a la ventana del admin: recibirá una notificación de que el
   intercambio quedó resuelto, y podrá verlo en la pestaña "Intercambios".

## Estructura del proyecto

```
turnos-app/
├── server.js                 # Punto de entrada: Express + Socket.IO
├── src/
│   ├── db.js                 # Esquema SQLite + datos semilla
│   ├── middleware/auth.js    # JWT + control de roles
│   ├── utils/
│   │   ├── reglasNegocio.js  # Horas máximas, cruces, compatibilidad de puesto
│   │   └── notificaciones.js # Notificaciones in-app + tiempo real
│   └── routes/
│       ├── auth.js           # Login, gestión de usuarios
│       ├── turnos.js         # Crear turnos, asignar, distribución automática
│       ├── disponibilidad.js # Disponibilidad semanal del empleado
│       ├── intercambios.js   # Publicar / aceptar / cancelar intercambios
│       ├── notificaciones.js # Bandeja de notificaciones
│       └── reportes.js       # Cobertura, horas por empleado, ranking
├── public/                   # Frontend (HTML/CSS/JS vanilla)
│   ├── index.html             # Login
│   ├── employee.html + js/employee.js
│   ├── admin.html + js/admin.js
│   └── js/{api.js, notificaciones.js}
└── data/turnos.db            # Base de datos SQLite (se crea sola)
```

## Modelo de datos (relacional)

- `usuarios` (id, nombre, email, password, rol, puesto, max_horas_semana)
- `turnos` (id, fecha, tipo_turno, hora_inicio, hora_fin, puesto_requerido, cantidad_requerida)
- `asignaciones` (turno_id, usuario_id, estado: asignado/publicado/cubierto/cancelado)
- `disponibilidad` (usuario_id, fecha, tipo_turno, disponible)
- `intercambios` (asignacion_id, solicitado_por, aceptado_por, estado)
- `notificaciones` (usuario_id, tipo, mensaje, leida)

## Notas para la sustentación académica

- La validación de reglas de negocio está centralizada en
  `src/utils/reglasNegocio.js`, separada de las rutas, para que sea fácil de
  explicar y de testear de forma aislada.
- El intercambio usa una transacción SQLite con actualización condicional
  (`WHERE estado = 'pendiente'`) como bloqueo optimista, para que si dos
  compañeros aceptan casi al mismo tiempo, solo uno gane la asignación.
- Los tokens JWT también se usan para autenticar la conexión WebSocket
  (cada usuario se une a una "room" `usuario_<id>`), de modo que las
  notificaciones en tiempo real solo llegan a quien corresponde.
- El límite de horas por defecto (42h/semana) referencia la Ley 2101 de 2021
  de Colombia; es un valor configurable por usuario (`max_horas_semana`), no
  un valor fijo en el código, por si tu negocio opera bajo otra legislación.
