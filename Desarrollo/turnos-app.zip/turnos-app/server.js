// server.js
require('dotenv').config();
const path = require('path');
const express = require('express');
const cors = require('cors');
const http = require('http');
const { Server } = require('socket.io');
const jwt = require('jsonwebtoken');

const { JWT_SECRET } = require('./src/middleware/auth');
const { setIo } = require('./src/utils/notificaciones');

const authRoutes = require('./src/routes/auth');
const turnosRoutes = require('./src/routes/turnos');
const disponibilidadRoutes = require('./src/routes/disponibilidad');
const intercambiosRoutes = require('./src/routes/intercambios');
const notificacionesRoutes = require('./src/routes/notificaciones');
const reportesRoutes = require('./src/routes/reportes');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });
setIo(io);

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// --- API ---------------------------------------------------------------
app.use('/api/auth', authRoutes);
app.use('/api/turnos', turnosRoutes);
app.use('/api/disponibilidad', disponibilidadRoutes);
app.use('/api/intercambios', intercambiosRoutes);
app.use('/api/notificaciones', notificacionesRoutes);
app.use('/api/reportes', reportesRoutes);

app.get('/api/health', (req, res) => res.json({ ok: true, hora: new Date().toISOString() }));

// --- WebSockets: cada usuario se une a su propia sala usando su JWT --------
io.use((socket, next) => {
  try {
    const token = socket.handshake.auth?.token;
    if (!token) return next(new Error('Falta token'));
    const payload = jwt.verify(token, JWT_SECRET);
    socket.user = payload;
    next();
  } catch (err) {
    next(new Error('Token inválido'));
  }
});

io.on('connection', (socket) => {
  socket.join(`usuario_${socket.user.id}`);
  if (socket.user.rol === 'admin') socket.join('admins');
});

// Fallback: cualquier ruta no-API sirve el frontend (SPA simple por archivos)
app.use((req, res, next) => {
  if (req.method !== 'GET' || req.path.startsWith('/api/') || req.path.startsWith('/socket.io/')) {
    return next();
  }
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// --- Manejador de errores genérico ------------------------------------------
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Error interno del servidor.' });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`\n🟢 Sistema de Turnos escuchando en http://localhost:${PORT}\n`);
});
